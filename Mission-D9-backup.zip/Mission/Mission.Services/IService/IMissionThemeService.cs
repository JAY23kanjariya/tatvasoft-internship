﻿using Mission.Entities.ViewModels.MissionTheme;

namespace Mission.Services.IService
{
    // CRUD operation - MissionTheme column
    public interface IMissionThemeService
    {
        // Create operation - CRUD operation for MissionTheme column
        Task AddMissionThemeAsync(UpsertMissionThemeRequestModel model);

        // Read operation - CRUD operation for MissionTheme column
        Task<List<MissionThemeResponseModel>> GetMissionThemeListAsync();

        // Update operation (fetching data) - CRUD operation for MissionTheme column
        Task<MissionThemeResponseModel?> GetMissionThemeByIdAsync(int missionThemeId);

        // Update operation (changing data) - CRUD operation for MissionTheme column
        Task<bool> UpdateMissionThemeAsync(UpsertMissionThemeRequestModel model);

        // delete operation - CRUD operation for MissionTheme column
        Task<bool> DeleteMissionTheme(int id);
    }
}
