﻿using Mission.Entities.ViewModels.Mission;
using Mission.Entities.ViewModels.MissionApplication;

namespace Mission.Services.IService
{// CRUD operation - Mission column
    public interface IMissionService
    {
        // Create operation - CRUD operation for Mission column
        Task AddMissionRequestAsync(AddMissionRequestModel model);

        // Read operation - CRUD operation for Mission column
        Task<List<MissionResponseModel>> GetMissionList();

        // Update operation (fetching data) - CRUD operation for Mission column
        Task<MissionRequestViewModel?> GetMissionById(int id);

        // Update operation (changing data)- CRUD operation for Mission column
        Task<bool> UpdateMission(MissionRequestViewModel model);

        // Delete operation - CRUD operation for Mission column
        Task<bool> DeleteMission(int missionId);

        // Client(user) - Read available Mission in website
        Task<List<ClientMissionResponseModel>> GetClientSideMissionList(int userId);

        // Client(user) - apply for mission
        Task<(bool result, string message)> ApplyMission(ApplyMissionRequestModel model);

        // Client(user) - Read available Mission in website
        Task<List<MissionApplicationResponseModel>> GetMissionApplicationList();

        //Admin approved-  Client(user) appled for mission
        Task<bool> MissionApplicationApprove(MissionApplicationResponseModel model);

        //admin - Delete Application Mission
        Task<bool> MissionApplicationDelete(MissionApplicationResponseModel model);
    }
}
