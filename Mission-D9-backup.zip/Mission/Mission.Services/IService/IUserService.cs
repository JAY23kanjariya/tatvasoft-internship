﻿using Mission.Entities.ViewModels;
using Mission.Entities.ViewModels.Login;
using Mission.Entities.ViewModels.User;

namespace Mission.Services.IService
{
    // CRUD operation - User column
    public interface IUserService
    {
        // for Login
        Task<ResponseResult> LogiUser(UserLoginRequestModel model);

        // Read operation - CRUD operation for User column
        Task<List<UserResponseModel>> GetUsersAsync();

        // Create operation - CRUD operation for User column
        Task<bool> RegisterUserAsync(AddUserRequestModel model);

        // Update operation (fetching data) - CRUD operation for User column
        Task<UserResponseModel?> GetLoginUserDetailById(int userId);

        // Update operation (changing data) - CRUD operation for User column
        Task<ResponseResult> UpdateUserAsync(UpdateUserRequestModel model, string imageUploadPath);

        // Delete operation - CRUD operation for User column
        Task<bool> DeleteUser(int userId);
    }
}
