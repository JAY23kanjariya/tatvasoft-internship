﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mission.Entities.ViewModels;

namespace Mission.Services.IService
{
    // Add column - Mission coloumn
    public interface ICommonService
    {
        // list of Country list
        List<DropDownResponseModel> CountryList();

        // list of City list
        List<DropDownResponseModel> CityList(int countryId);

        // list of MissionTheme list
        List<DropDownResponseModel> MissionThemeList();

        // list of MissionSkill list
        List<DropDownResponseModel> MissionSkillList();
    }
}