﻿using Mission.Entities.ViewModels;
using Mission.Repositories.IRepository;
using Mission.Services.IService;

namespace Mission.Services.Service
{
    // Add column - Mission coloumn
    public class CommonService(ICommonRepository commonRepository) : ICommonService
    {
        private readonly ICommonRepository _commonRepository = commonRepository;

        // list of Country list
        public List<DropDownResponseModel> CountryList()
        {
            return _commonRepository.CountryList();
        }

        // list of City list
        public List<DropDownResponseModel> CityList(int countryId)
        {
            return _commonRepository.CityList(countryId);
        }

        // list of MissionTheme list
        public List<DropDownResponseModel> MissionThemeList()
        {
            return _commonRepository.MissionThemeList();
        }

        // list of MissionSkill list
        public List<DropDownResponseModel> MissionSkillList()
        {
            return _commonRepository.MissionSkillList();
        }
    }
}