﻿using Mission.Entities.ViewModels.Mission;
using Mission.Entities.ViewModels.MissionApplication;
using Mission.Repositories.IRepository;
using Mission.Services.IService;

namespace Mission.Services.Service
{
    // CRUD operation - Mission column
    public class MissionService(IMissionRepository missionRepository) : IMissionService
    {
        private readonly IMissionRepository _missionRepository = missionRepository;

        // Create operation - CRUD operation for Mission column
        public async Task AddMissionRequestAsync(AddMissionRequestModel model)
        {
            await _missionRepository.AddMissionRequestAsync(model);
            return;
        }

        // Read operation - CRUD operation for Mission column
        public async Task<List<MissionResponseModel>> GetMissionList()
        {
            return await _missionRepository.GetMissionList();
        }

        // Update operation (fetching data) - CRUD operation for Mission column
        public Task<MissionRequestViewModel?> GetMissionById(int id)
        {
            return _missionRepository.GetMissionById(id);
        }

        // Update operation (changing data)- CRUD operation for Mission column
        public async Task<bool> UpdateMission(MissionRequestViewModel model)
        {
            return await _missionRepository.UpdateMission(model);
        }

        // Delete operation - CRUD operation for Mission column
        public async Task<bool> DeleteMission(int missionId)
        {
            return await _missionRepository.DeleteMission(missionId);
        }

        // Client(user) - Read available Mission in website
        public async Task<List<ClientMissionResponseModel>> GetClientSideMissionList(int userId)
        {
            return await _missionRepository.GetClientSideMissionList(userId);
        }

        // Client(user) - apply for mission
        public async Task<(bool result, string message)> ApplyMission(ApplyMissionRequestModel model)
        {
            return await _missionRepository.ApplyMission(model);
        }

        // Client(user) - Read available Mission in website
        public async Task<List<MissionApplicationResponseModel>> GetMissionApplicationList()
        {
            return await _missionRepository.GetMissionApplicationList();
        }

        //Admin approved-  Client(user) appled for mission
        public async Task<bool> MissionApplicationApprove(MissionApplicationResponseModel model)
        {
            return await _missionRepository.MissionApplicationApprove(model);
        }

        //admin - Delete Application Mission
        public async Task<bool> MissionApplicationDelete(MissionApplicationResponseModel model)
        {
            return await _missionRepository.MissionApplicationDelete(model);
        }
    }
}
