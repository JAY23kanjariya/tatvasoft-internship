﻿using Mission.Entities.ViewModels.MissionTheme;
using Mission.Repositories.IRepository;
using Mission.Services.IService;

namespace Mission.Services.Service
{
    // CRUD operation - MissionTheme column
    public class MissionThemeService(IMissionThemeRepository missionThemeRepository) : IMissionThemeService
    {
        private readonly IMissionThemeRepository _missionThemeRepository = missionThemeRepository;

        // Create operation - CRUD operation for MissionTheme column
        public async Task AddMissionThemeAsync(UpsertMissionThemeRequestModel model)
        {
            await _missionThemeRepository.AddMissionThemeAsync(model);
            return;
        }

        // delete operation - CRUD operation for MissionTheme column
        public async Task<bool> DeleteMissionTheme(int id)
        {
            return await _missionThemeRepository.DeleteMissionTheme(id);
        }

        // Update operation (fetching data) - CRUD operation for MissionTheme column
        public async Task<MissionThemeResponseModel?> GetMissionThemeByIdAsync(int missionThemeId)
        {
            return await _missionThemeRepository.GetMissionThemeByIdAsync(missionThemeId);
        }

        // Read operation - CRUD operation for MissionTheme column
        public async Task<List<MissionThemeResponseModel>> GetMissionThemeListAsync()
        {
            return await _missionThemeRepository.GetMissionThemeListAsync();
        }
        // Update operation (changing data) - CRUD operation for MissionTheme column
        public async Task<bool> UpdateMissionThemeAsync(UpsertMissionThemeRequestModel model)
        {
            return await _missionThemeRepository.UpdateMissionThemeAsync(model);
        }
    }
}
