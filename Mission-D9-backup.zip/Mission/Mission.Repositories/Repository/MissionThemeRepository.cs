﻿using Microsoft.EntityFrameworkCore;
using Mission.Entities;
using Mission.Entities.Models;
using Mission.Entities.ViewModels.MissionTheme;
using Mission.Repositories.IRepository;

namespace Mission.Repositories.Repository
{
    // CRUD operation - MissionTheme column
    public class MissionThemeRepository(MissionDbContext dbContext) : IMissionThemeRepository
    {
        private readonly MissionDbContext _dbContext = dbContext;

        // Create operation - CRUD operation for MissionTheme column
        public async Task AddMissionThemeAsync(UpsertMissionThemeRequestModel model)
        {
            var missionTheme = new MissionTheme()
            {
                ThemeName = model.ThemeName,
                Status = model.Status,
            };

            _dbContext.MissionThemes.Add(missionTheme);

            await _dbContext.SaveChangesAsync();
        }

        // Read operation - CRUD operation for MissionTheme column
        public async Task<List<MissionThemeResponseModel>> GetMissionThemeListAsync()
            {
                return await _dbContext.MissionThemes.Select(m => new MissionThemeResponseModel(m)).ToListAsync();
            }

        // Update operation (fetching data) - CRUD operation for MissionTheme column
        public async Task<MissionThemeResponseModel?> GetMissionThemeByIdAsync(int missionThemeId)
            {
                var missionTheme = await _dbContext.MissionThemes.FindAsync(missionThemeId);

                if (missionTheme == null)
                    return null;

                return new MissionThemeResponseModel(missionTheme);
            }

        // Update operation (changing data) - CRUD operation for MissionTheme column
        public async Task<bool> UpdateMissionThemeAsync(UpsertMissionThemeRequestModel model)
        {
            var missionTheme = _dbContext.MissionThemes.Find(model.Id);

            if (missionTheme == null)
                return false;

            missionTheme.ThemeName = model.ThemeName;
            missionTheme.Status = model.Status;

            _dbContext.MissionThemes.Update(missionTheme);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        // delete operation - CRUD operation for MissionTheme column
        public async Task<bool> DeleteMissionTheme(int id)
        {
            var missionTheme = _dbContext.MissionThemes.Find(id);

            if (missionTheme == null)
                return false;

            _dbContext.MissionThemes.Remove(missionTheme);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
