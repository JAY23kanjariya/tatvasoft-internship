﻿using Mission.Entities;
using Mission.Entities.ViewModels;
using Mission.Repositories.IRepository;

namespace Mission.Repositories.Repository
{
    public class CommonRepository(MissionDbContext dbContext) : ICommonRepository
    {
        // Add column - Mission coloumn
        private readonly MissionDbContext _dbContext = dbContext;

        // list of Country list
        public List<DropDownResponseModel> CountryList()
        {
            var countries = _dbContext.Countries
                .OrderBy(c => c.CountryName)
                .Select(c => new DropDownResponseModel(c.Id, c.CountryName))
                .ToList();

            return countries;
        }

        // list of City list
        public List<DropDownResponseModel> CityList(int countryId)
        {
            var cities = _dbContext.Cities
                .Where(c => c.CountryId == countryId)
                .OrderBy(c => c.CityName)
                .Select(c => new DropDownResponseModel(c.Id, c.CityName))
                .ToList();

            return cities;
        }

        // list of MissionTheme list
        public List<DropDownResponseModel> MissionThemeList()
        {
            var missionThemes = _dbContext.MissionThemes
                .Where(mt => mt.Status == "active")
                .Select(mt => new DropDownResponseModel(mt.Id, mt.ThemeName))
                .Distinct()
                .ToList();

            return missionThemes;
        }

        // list of MissionSkill list
        public List<DropDownResponseModel> MissionSkillList()
        {
            var missionSkill = _dbContext.MissionSkills
                .Where(ms => ms.Status == "active")
                .Select(ms => new DropDownResponseModel(ms.Id, ms.SkillName))
                .ToList();

            return missionSkill;
        }
    }
}
