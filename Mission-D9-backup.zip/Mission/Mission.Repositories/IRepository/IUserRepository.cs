﻿using Mission.Entities.ViewModels.Login;
using Mission.Entities.ViewModels.User;

namespace Mission.Repositories.IRepository
{
    // CRUD operation - User column
    public interface IUserRepository
    {
        // for Login
        Task<(UserLoginResponseModel? response, string message)> LogiUser(UserLoginRequestModel model);

        // Read operation - CRUD operation for User column
        Task<List<UserResponseModel>> GetUsersAsync();

        // Read operation - CRUD operation for User column
        Task<bool> RegisterUserAsync(AddUserRequestModel model);

        // Update operation (fetching data) - CRUD operation for User column
        Task<UserResponseModel?> GetLoginUserDetailById(int userId);

        // Update operation (changing data) - CRUD operation for User column
        Task<(bool response, string message)> UpdateUserAsync(UpdateUserRequestModel model, string imageUploadPath);

        // Delete operation - CRUD operation for User column
        Task<bool> DeleteUser(int userId);
    }
}
