﻿using Mission.Entities.ViewModels.MissionSkill;

namespace Mission.Repositories.IRepository
{
    // CRUD operation - MissionSkill column
    public interface IMissionSkillRepository
    {
        // Create operation - CRUD operation for MissionSkill column
        Task AddMissionSkillAsync(UpsertMissionSkillRequestModel model);

        // Read operation - CRUD operation for MissionSkill column
        Task<List<MissionSkillResponseModel>> GetMissionSkillListAsync();

        // Update operation (fetching data) - CRUD operation for MissionSkill column
        Task<MissionSkillResponseModel?> GetMissionSkillByIdAsync(int missionSkillId);

        // Update operation (changing data)- CRUD operation for MissionSkill column
        Task<bool> UpdateMissionSkillAsync(UpsertMissionSkillRequestModel model);

        // delete operation - CRUD operation for MissionSkill column
        Task<bool> DeleteMissionSkill(int id);
    }
}
