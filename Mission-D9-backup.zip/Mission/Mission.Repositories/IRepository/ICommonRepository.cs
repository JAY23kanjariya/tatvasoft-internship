﻿using Mission.Entities.ViewModels;

namespace Mission.Repositories.IRepository
{
    // Add column - Mission coloumn
    public interface ICommonRepository
    {
        // list of Country list
        List<DropDownResponseModel> CountryList();

        // list of City list
        List<DropDownResponseModel> CityList(int countryId);

        // list of MissionTheme list
        List<DropDownResponseModel> MissionThemeList();

        // list of MissionSkill list
        List<DropDownResponseModel> MissionSkillList();
    }
}
