﻿using System.ComponentModel.DataAnnotations;

namespace Mission.Entities.Models
{
    // table detail - Country
    public class Country
    {
        [Key]
        public int Id { get; set; }
        public string CountryName { get; set; }
    }
}
